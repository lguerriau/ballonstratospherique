#include "widget.h"
#include "ui_widget.h"
#include <QSerialPortInfo>
#include <QDebug>

Widget::Widget(QWidget *parent) : QWidget(parent), ui(new Ui::Widget) {
    ui->setupUi(this);
    serial = new QSerialPort(this);

    // --- CONFIGURATION CIBLÉE SUR LINUX ---
    serial->setPortName("/dev/ttyACM0"); // Ton port spécifique
    serial->setBaudRate(QSerialPort::Baud115200);
    serial->setDataBits(QSerialPort::Data8);
    serial->setParity(QSerialPort::NoParity);
    serial->setStopBits(QSerialPort::OneStop);
    serial->setFlowControl(QSerialPort::NoFlowControl);

    if (serial->open(QIODevice::ReadWrite)) {
        qDebug() << "Succès : Liaison établie sur /dev/ttyACM0";
        ui->lbl_image_principale->setText("[ SYSTÈME CONNECTÉ ]");
    } else {
        qDebug() << "Erreur : Impossible d'ouvrir /dev/ttyACM0. Erreur :" << serial->errorString();
        ui->lbl_image_principale->setText("[ ERREUR DE CONNEXION ]");
    }

    connect(serial, &QSerialPort::readyRead, this, &Widget::lireDonneesSerie);
}

Widget::~Widget() {
    if (serial->isOpen()) serial->close();
    delete ui;
}

// Action au clic sur le bouton
void Widget::on_btn_envoyer_clicked() {
    QString commandeSelectionnee = ui->combo_requetes->currentText();
    char charAEnvoyer = ' ';

    // Mapping entre le texte de l'UI et tes commandes ESP32
    if (commandeSelectionnee == "RÉCUPÉRER RSSI & SNR") {
        charAEnvoyer = 'm';
    }
    // Tu peux ajouter d'autres conditions ici pour 't', etc.

    if (serial->isOpen() && charAEnvoyer != ' ') {
        serial->write(&charAEnvoyer, 1);

        // Ajouter une ligne dans le tableau de log
        int row = ui->table_requetes->rowCount();
        ui->table_requetes->insertRow(row);
        ui->table_requetes->setItem(row, 0, new QTableWidgetItem(QDateTime::currentDateTime().toString("hh:mm:ss")));
        ui->table_requetes->setItem(row, 1, new QTableWidgetItem("REQ: " + commandeSelectionnee));

        timerLatence.start(); // On lance le chrono pour la latence
    }
}

// Lecture et parsing des données venant de la Gateway
void Widget::lireDonneesSerie() {
    QByteArray data = serial->readAll();
    QString message = QString::fromUtf8(data).trimmed();

    if (message.isEmpty()) return;

    // 1. Mise à jour du tableau (colonne du milieu)
    int lastRow = ui->table_requetes->rowCount() - 1;
    if (lastRow >= 0) {
        // On affiche directement "RSSI:-102 | SNR:7" dans la cellule
        QString affichageTableau = message.replace("|", " | ");
        ui->table_requetes->setItem(lastRow, 1, new QTableWidgetItem(affichageTableau));

        // Calcul de la latence finale
        ui->table_requetes->setItem(lastRow, 2, new QTableWidgetItem(QString::number(timerLatence.elapsed())));
    }
    }
