#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QSerialPort>
#include <QDateTime>
#include <QElapsedTimer>

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget {
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private slots:
    void on_btn_envoyer_clicked(); // Clic sur "ÉMETTRE REQUÊTE"
    void lireDonneesSerie();       // Lecture du retour LoRa

private:
    Ui::Widget *ui;
    QSerialPort *serial;           // Le lien vers l'ESP32
    QElapsedTimer timerLatence;    // Pour calculer la latence (ms)
};
#endif
